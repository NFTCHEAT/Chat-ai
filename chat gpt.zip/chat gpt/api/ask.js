export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST" });

  const { question } = req.body || {};
  const q = String(question || "").trim();
  if (!q) return res.status(400).json({ error: "Empty question" });

  const key = process.env.OPENAI_API_KEY || "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";
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";

  if (!key || key.startsWith("TEST")) {
    return res.status(200).json({
      answer: `✅ ТЕСТ-ОТВЕТ\n\nТы спросил: "${q}"\n\nДобавь OPENAI_API_KEY в Vercel Environment Variables.`
    });
  }

  const resp = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${key}`
    },
    body: JSON.stringify({
      model,
      input: [
        { role: "system", content: [{ type: "text", text: "Ты полезный ассистент. Отвечай кратко и по делу." }] },
        { role: "user", content: [{ type: "text", text: q }] }
      ]
    })
  });

  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) {
    return res.status(resp.status).json({ error: data?.error?.message || "OpenAI API error", details: data });
  }

  return res.status(200).json({ answer: data?.output_text || "(пустой ответ)" });
}